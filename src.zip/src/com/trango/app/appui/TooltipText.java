/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.trango.app.appui;

/**
 *
 * @author bilal.iqbal
 */
public class TooltipText {
public static String messsageSendOnlineOption="Send files to your contact who is not on your network";
public static String messsageSendHotspotOption="Send files to your contacts by creating a hotspot connection. This is a direct, device to device transfer method. Ideal for devices in close proximity.";
public static String messsageSendOfflineOption="Send files to your contact who is on your network";
public static String messsageSendEncryptOption="Apply AES encryption for further security";
public static String messsageSendFolderOption="This allows you to send a pre-existing folder";
public static String messsageNotificationLabel="Notifications ";
public static String messsageContactrequestLabel="Received contact requests from others";

public static String messsageSendMyselfOption="Send file to your another logged in device on the same network";
public static String messsageCreatehotspot="Create hotspot connection for transfering file";
public static String messsageSendShareableOption="This will allow you to share with others who don't have the trango application. This is a real-time link and not an upload so both you and the receiver will need to be online for the transfer to take place.";
public static String messsageShowWifiPassword="Show careated hotspot name and password";
public static String messsageTermandconditionLink=" Terms and conditions for Trango";
public static String messsagePrivacypolicyLink="Privacy policy of Trango";
public static String messsageUploadbutton="Choose files/folder for sending to your contact";

public static String messsageChangeDirectory="Change default directory to save recieved files";
public static String messsageChangePassword="Change password of your account"; 
public static String messsageAboutUs="Trango.io";
public static String messsageUpgradeAccount="Upgrade your free account to pro account";
public static String messsageSignedinDevices="Show your other signed in devices with same email address";
public static String messsageMenulogout="Logout from account";

public static String messagedeactivateAccount="Deactivate your account";
public static String messageUnsubscribeAccount="Unsubscribe pro version";

public static String messagehelp="Additional video resources regarding how to use the application";

public static String messageShowTransfer1= "Show transfer progress1";
public static String messageShowTransfer2= "Show transfer progress2";
public static String messageProgressUpdate= "Show the updated progerss of current file transfer";
  


public static String messageAlreadyLoggedIn="You are licensed to use this application on three devices. Signout of atleast one device in order to signin here";




}
